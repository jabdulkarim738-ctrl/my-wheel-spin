import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Trash2, Plus, Palette, Shuffle, ArrowUp, Upload, Settings, X } from 'lucide-react';

/**
 * Design Philosophy: Playful & Interactive Minimalism
 * - Vibrant wheel colors for joy and engagement
 * - Smooth animations for satisfying interaction
 * - Clean white background to focus on the wheel
 * - Responsive layout with wheel as focal point
 * - 3D cube toggle for advanced/simple mode switching
 */

const DEFAULT_CHOICES = [
  'Choice 1',
  'Choice 2',
  'Choice 3',
  'Choice 4',
  'Choice 5',
  'Choice 6',
  'Choice 7',
];

const DEFAULT_WHEEL_COLORS = [
  '#FF6B6B', // Red
  '#FFA500', // Orange
  '#FFD93D', // Yellow
  '#6BCB77', // Green
  '#4D96FF', // Blue
  '#9D4EDD', // Purple
  '#FF006E', // Pink
  '#00D9FF', // Cyan
];

const PRESET_COLOR_PALETTES = [
  {
    name: 'Vibrant',
    colors: ['#FF6B6B', '#FFA500', '#FFD93D', '#6BCB77', '#4D96FF', '#9D4EDD', '#FF006E', '#00D9FF'],
  },
  {
    name: 'Pastel',
    colors: ['#FFB3BA', '#FFCCCB', '#FFFFBA', '#BAE1BA', '#BAC7FF', '#E1BAFF', '#FFB3E6', '#BAF3FF'],
  },
  {
    name: 'Dark',
    colors: ['#8B0000', '#CC5500', '#996600', '#004D00', '#000066', '#330066', '#660033', '#003366'],
  },
  {
    name: 'Neon',
    colors: ['#FF006E', '#00D9FF', '#FFBE0B', '#FB5607', '#8338EC', '#3A86FF', '#06FFA5', '#FF006E'],
  },
];

interface Choice {
  id: string;
  name: string;
  color: string;
  image?: string;
  weight?: number;
  sound?: string;
  popupMessage?: string;
}

export default function Home() {
  const [choices, setChoices] = useState<Choice[]>(
    DEFAULT_CHOICES.map((name, idx) => ({
      id: `choice-${idx}`,
      name,
      color: DEFAULT_WHEEL_COLORS[idx % DEFAULT_WHEEL_COLORS.length],
      weight: 1,
    }))
  );
  const [rotation, setRotation] = useState(0);
  const rotationRef = useRef(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [newChoice, setNewChoice] = useState('');
  const [showResultDialog, setShowResultDialog] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [editingColorIndex, setEditingColorIndex] = useState<number | null>(null);
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [editingImageIndex, setEditingImageIndex] = useState<number | null>(null);
  const [isAdvancedMode, setIsAdvancedMode] = useState(false);
  const [cubeRotation, setCubeRotation] = useState(0);
  const [editingAdvancedIndex, setEditingAdvancedIndex] = useState<number | null>(null);
  const [showAdvancedDialog, setShowAdvancedDialog] = useState(false);
  const [editingWeightIndex, setEditingWeightIndex] = useState<number | null>(null);
  const [weightInputValue, setWeightInputValue] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const weightInputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Preload audio on component mount
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.preload = 'auto';
    }
  }, []);

  const handleSpin = () => {
    if (isSpinning || choices.length === 0) return;

    setIsSpinning(true);
    
    // Play wheel spinning sound
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.volume = 1;
      audioRef.current.play().catch(err => console.log('Audio play failed:', err));
    }
    
    // Calculate weighted random index
    const totalWeight = choices.reduce((sum, c) => sum + (c.weight || 1), 0);
    let random = Math.random() * totalWeight;
    let randomIndex = 0;
    for (let i = 0; i < choices.length; i++) {
      random -= (choices[i].weight || 1);
      if (random <= 0) {
        randomIndex = i;
        break;
      }
    }

    const segmentDegrees = 360 / choices.length;
    // Add random offset from 0-100% of segment width for natural stopping
    const stopOffset = Math.random() * segmentDegrees;
    
    // Target position on wheel (0-360)
    const targetPosition = randomIndex * segmentDegrees + stopOffset;
    
    // EXTREMELY FAST SPIN - 50-100 full rotations in 7 seconds with deceleration
    const extremeSpins = 50 + Math.floor(Math.random() * 50);
    const finalRotation = rotation + extremeSpins * 360 + targetPosition;
    
    setRotation(finalRotation);
    setSelectedIndex(randomIndex);

    // Show result after 10 seconds with smooth single transition
    setTimeout(() => {
      setIsSpinning(false);
      setShowResultDialog(true);
      if (audioRef.current) {
        audioRef.current.pause();
      }
    }, 10000);
  };

  const handleAddChoice = () => {
    if (newChoice.trim()) {
      const newId = `choice-${Date.now()}`;
      const colorIndex = choices.length % DEFAULT_WHEEL_COLORS.length;
      setChoices([
        ...choices,
        {
          id: newId,
          name: newChoice,
          color: DEFAULT_WHEEL_COLORS[colorIndex],
          weight: 1,
        },
      ]);
      setNewChoice('');
    }
  };

  const handleRemoveChoice = (id: string) => {
    const indexToRemove = choices.findIndex(c => c.id === id);
    setChoices(choices.filter(c => c.id !== id));
    if (selectedIndex === indexToRemove) {
      setSelectedIndex(null);
    }
  };

  const handleRemoveFromResult = () => {
    if (selectedIndex !== null) {
      handleRemoveChoice(choices[selectedIndex].id);
    }
    setShowResultDialog(false);
    setSelectedIndex(null);
  };

  const handleKeepInWheel = () => {
    setShowResultDialog(false);
  };

  const handleClearAll = () => {
    setChoices([]);
    setSelectedIndex(null);
    setRotation(0);
    rotationRef.current = 0;
  };

  const handleUpdateColor = (index: number, color: string) => {
    const updatedChoices = [...choices];
    updatedChoices[index].color = color;
    setChoices(updatedChoices);
    setEditingColorIndex(null);
  };

  const handleApplyPalette = (palette: typeof PRESET_COLOR_PALETTES[0]) => {
    const updatedChoices = choices.map((choice, idx) => ({
      ...choice,
      color: palette.colors[idx % palette.colors.length],
    }));
    setChoices(updatedChoices);
    setShowColorPicker(false);
  };

  const handleShuffle = () => {
    const shuffled = [...choices].sort(() => Math.random() - 0.5);
    setChoices(shuffled);
  };

  const handleSort = () => {
    const sorted = [...choices].sort((a, b) => a.name.localeCompare(b.name));
    setChoices(sorted);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || editingImageIndex === null) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const imageData = event.target?.result as string;
      setChoices((prevChoices) => {
        const updated = [...prevChoices];
        updated[editingImageIndex].image = imageData;
        return updated;
      });
      setShowImageDialog(false);
      setEditingImageIndex(null);
    };
    reader.readAsDataURL(file);
  };

  const openImageUpload = (index: number) => {
    setEditingImageIndex(index);
    setShowImageDialog(true);
  };

  const removeImage = (index: number) => {
    setChoices((prevChoices) => {
      const updated = [...prevChoices];
      delete updated[index].image;
      return updated;
    });
  };

  const toggleAdvancedMode = () => {
    setIsAdvancedMode(!isAdvancedMode);
    setCubeRotation(cubeRotation + 180);
  };

  const openAdvancedEditor = (index: number) => {
    setEditingAdvancedIndex(index);
    setShowAdvancedDialog(true);
  };

  const updateAdvancedSettings = (field: string, value: any) => {
    if (editingAdvancedIndex === null) return;
    const updated = [...choices];
    updated[editingAdvancedIndex] = {
      ...updated[editingAdvancedIndex],
      [field]: value,
    };
    setChoices(updated);
  };

  const startEditingWeight = (index: number) => {
    setEditingWeightIndex(index);
    setWeightInputValue(String(choices[index].weight || 1));
    setTimeout(() => weightInputRef.current?.focus(), 0);
  };

  const finishEditingWeight = () => {
    if (editingWeightIndex === null) return;
    const numValue = parseFloat(weightInputValue);
    if (!isNaN(numValue) && numValue > 0) {
      const updated = [...choices];
      updated[editingWeightIndex].weight = numValue;
      setChoices(updated);
    }
    setEditingWeightIndex(null);
    setWeightInputValue('');
  };

  const handleWeightKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      finishEditingWeight();
    } else if (e.key === 'Escape') {
      setEditingWeightIndex(null);
      setWeightInputValue('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col items-center justify-center p-4">
      {/* Audio element for wheel spinning sound */}
      <audio
        ref={audioRef}
        src="/manus-storage/mixkit-bike-wheel-spinning-1613_e9e0ffb9.wav"
        preload="auto"
      />
      
      <div className="w-full max-w-4xl">
        {/* Header with 3D Cube Toggle */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-center flex-1">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-2">
              Spin the Wheel
            </h1>
            <p className="text-slate-600 text-lg">
              {isAdvancedMode ? 'Advanced Settings Mode' : 'Add your choices and spin to get a random result'}
            </p>
          </div>
          
          {/* 3D Cube Toggle */}
          <div
            onClick={toggleAdvancedMode}
            className="relative w-16 h-16 cursor-pointer ml-4 flex-shrink-0"
            style={{
              perspective: '1000px',
            }}
          >
            <div
              className="w-full h-full relative transition-transform duration-500"
              style={{
                transformStyle: 'preserve-3d',
                transform: `rotateY(${cubeRotation}deg)`,
              }}
            >
              {/* Front face - Simple */}
              <div
                className="absolute w-full h-full bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg flex items-center justify-center text-white font-bold text-2xl hover:shadow-xl transition-shadow"
                style={{
                  backfaceVisibility: 'hidden',
                }}
              >
                ⚙️
              </div>
              {/* Back face - Advanced */}
              <div
                className="absolute w-full h-full bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg flex items-center justify-center text-white font-bold text-2xl hover:shadow-xl transition-shadow"
                style={{
                  backfaceVisibility: 'hidden',
                  transform: 'rotateY(180deg)',
                }}
              >
                ✨
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Wheel */}
          {!isAdvancedMode && (
            <div className="flex-1 flex flex-col items-center justify-center">
              <div className="relative w-full aspect-square max-w-md">
                {/* Pointer */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 z-10 flex flex-col items-center">
                  <div className="w-0 h-0 border-l-8 border-r-8 border-t-12 border-l-transparent border-r-transparent border-t-slate-900"></div>
                </div>

                {/* Wheel */}
                <div
                  className="w-full h-full rounded-full shadow-2xl"
                  style={{
                    transform: `rotate(${rotation}deg)`,
                    transition: isSpinning ? 'transform 10s cubic-bezier(0.25, 0.46, 0.45, 0.94)' : 'none',
                    filter: isSpinning ? 'blur(0.5px)' : 'none',
                    background: `conic-gradient(
                      ${choices
                        .map(
                          (choice, i) => {
                            const segmentSize = 360 / choices.length;
                            const startDeg = i * segmentSize;
                            const endDeg = (i + 1) * segmentSize;
                            return `${choice.color} ${startDeg}deg ${endDeg}deg`;
                          }
                        )
                        .join(', ')}
                    )`,
                  }}
                >
                  {/* Segments with text and images */}
                  <svg
                    className="w-full h-full absolute inset-0"
                    viewBox="0 0 200 200"
                    style={{ pointerEvents: 'none' }}
                  >
                    {choices.map((choice, index) => {
                      const segmentDegrees = 360 / choices.length;
                      const startAngle = (index * segmentDegrees * Math.PI) / 180;
                      const endAngle = ((index + 1) * segmentDegrees * Math.PI) / 180;
                      const midAngle = (startAngle + endAngle) / 2;
                      const textRadius = 65;
                      const x = 100 + textRadius * Math.cos(midAngle - Math.PI / 2);
                      const y = 100 + textRadius * Math.sin(midAngle - Math.PI / 2);
                      const textAngle = (midAngle * 180) / Math.PI - 90;
                      const imageRadius = 50;
                      const imageX = 100 + imageRadius * Math.cos(midAngle - Math.PI / 2);
                      const imageY = 100 + imageRadius * Math.sin(midAngle - Math.PI / 2);

                      return (
                        <g key={choice.id}>
                          {choice.image && (
                            <image
                              x={imageX - 8}
                              y={imageY - 8}
                              width="16"
                              height="16"
                              href={choice.image}
                              style={{
                                transform: `rotate(${textAngle}deg)`,
                                transformOrigin: `${imageX}px ${imageY}px`,
                              }}
                            />
                          )}
                          <text
                            x={x}
                            y={y}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fill="white"
                            fontSize="14"
                            fontWeight="bold"
                            transform={`rotate(${textAngle} ${x} ${y})`}
                            style={{
                              textShadow: '0 2px 4px rgba(0,0,0,0.3)',
                              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))',
                            }}
                          >
                            {choice.name}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                {/* Center circle - clickable to spin */}
                <div 
                  className="absolute inset-0 flex items-center justify-center cursor-pointer group"
                  onClick={handleSpin}
                >
                  <div className="w-16 h-16 bg-white rounded-full shadow-lg flex items-center justify-center group-hover:shadow-xl group-hover:scale-110 transition-all duration-200">
                    <div className="w-12 h-12 bg-slate-100 rounded-full group-hover:bg-slate-200 transition-colors"></div>
                  </div>
                </div>
              </div>

              {/* Spin Button */}
              <Button
                onClick={handleSpin}
                disabled={isSpinning || choices.length === 0}
                className="mt-8 px-8 py-6 text-xl font-bold bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSpinning ? 'SPINNING FAST!' : 'SPIN THE WHEEL'}
              </Button>
            </div>
          )}

          {/* Sidebar - Choices List & Controls */}
          <div className="flex-1 flex flex-col gap-4">
            {/* Add New Choice */}
            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-bold text-slate-900 mb-3">Add Choice</h2>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter choice..."
                  value={newChoice}
                  onChange={(e) => setNewChoice(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddChoice()}
                  className="flex-1"
                />
                <Button
                  onClick={handleAddChoice}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  <Plus size={20} />
                </Button>
              </div>
            </div>

            {/* Control Buttons */}
            <div className="bg-white rounded-lg shadow-md p-4">
              <h2 className="text-lg font-bold text-slate-900 mb-3">Controls</h2>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={handleShuffle}
                  variant="outline"
                  className="flex items-center justify-center gap-2"
                >
                  <Shuffle size={18} />
                  Shuffle
                </Button>
                <Button
                  onClick={handleSort}
                  variant="outline"
                  className="flex items-center justify-center gap-2"
                >
                  <ArrowUp size={18} />
                  Sort
                </Button>
                <Button
                  onClick={() => setShowColorPicker(true)}
                  variant="outline"
                  className="flex items-center justify-center gap-2"
                >
                  <Palette size={18} />
                  Colors
                </Button>
                <Button
                  onClick={handleClearAll}
                  variant="outline"
                  className="flex items-center justify-center gap-2 text-red-500 hover:text-red-600"
                >
                  <Trash2 size={18} />
                  Clear
                </Button>
              </div>
            </div>

            {/* Choices List */}
            <div className="bg-white rounded-lg shadow-md p-4 flex-1 overflow-y-auto max-h-96">
              <h2 className="text-lg font-bold text-slate-900 mb-3">Choices ({choices.length})</h2>
              <div className="space-y-2">
                {choices.map((choice, index) => (
                  <div
                    key={choice.id}
                    className="flex items-center gap-2 p-2 bg-slate-50 rounded hover:bg-slate-100 transition-colors"
                  >
                    <div
                      className="w-6 h-6 rounded-full flex-shrink-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                      style={{ backgroundColor: choice.color }}
                      onClick={() => {
                        setEditingColorIndex(index);
                        setShowColorPicker(true);
                      }}
                    ></div>
                    <span className="flex-1 text-sm font-medium text-slate-900 truncate">
                      {choice.name}
                    </span>
                    {isAdvancedMode && (
                      <>
                        <Button
                          onClick={() => openImageUpload(index)}
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                        >
                          <Upload size={14} />
                        </Button>
                        <Button
                          onClick={() => openAdvancedEditor(index)}
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                        >
                          <Settings size={14} />
                        </Button>
                      </>
                    )}
                    <Button
                      onClick={() => handleRemoveChoice(choice.id)}
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0 text-red-500 hover:text-red-600"
                    >
                      <X size={14} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Color Picker Dialog */}
      <Dialog open={showColorPicker} onOpenChange={setShowColorPicker}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingColorIndex !== null ? 'Edit Color' : 'Choose Color Palette'}
            </DialogTitle>
          </DialogHeader>
          {editingColorIndex !== null ? (
            <div className="space-y-4">
              <div className="flex gap-2 flex-wrap">
                {DEFAULT_WHEEL_COLORS.map((color) => (
                  <button
                    key={color}
                    className="w-12 h-12 rounded-lg shadow-md hover:shadow-lg transition-shadow border-2 border-transparent hover:border-slate-300"
                    style={{ backgroundColor: color }}
                    onClick={() => {
                      handleUpdateColor(editingColorIndex, color);
                      setEditingColorIndex(null);
                    }}
                  ></button>
                ))}
              </div>
              <Input
                type="color"
                value={choices[editingColorIndex]?.color || '#000000'}
                onChange={(e) => handleUpdateColor(editingColorIndex, e.target.value)}
                className="h-12"
              />
            </div>
          ) : (
            <div className="space-y-3">
              {PRESET_COLOR_PALETTES.map((palette) => (
                <button
                  key={palette.name}
                  onClick={() => handleApplyPalette(palette)}
                  className="w-full p-3 rounded-lg border-2 border-slate-200 hover:border-blue-500 hover:bg-blue-50 transition-all text-left"
                >
                  <div className="font-bold text-slate-900 mb-2">{palette.name}</div>
                  <div className="flex gap-1">
                    {palette.colors.map((color) => (
                      <div
                        key={color}
                        className="flex-1 h-6 rounded"
                        style={{ backgroundColor: color }}
                      ></div>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Image Upload Dialog */}
      <Dialog open={showImageDialog} onOpenChange={setShowImageDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Image</DialogTitle>
          </DialogHeader>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
          <div className="space-y-4">
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            >
              Choose Image
            </Button>
            {editingImageIndex !== null && choices[editingImageIndex]?.image && (
              <div className="space-y-2">
                <img
                  src={choices[editingImageIndex].image}
                  alt="preview"
                  className="w-full h-32 object-cover rounded-lg"
                />
                <Button
                  onClick={() => removeImage(editingImageIndex)}
                  variant="destructive"
                  className="w-full"
                >
                  Remove Image
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Advanced Settings Dialog */}
      <Dialog open={showAdvancedDialog} onOpenChange={setShowAdvancedDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Advanced Settings</DialogTitle>
          </DialogHeader>
          {editingAdvancedIndex !== null && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-1">
                  Weight (probability multiplier)
                </label>
                <Input
                  ref={weightInputRef}
                  type="number"
                  min="0.1"
                  step="0.1"
                  value={choices[editingAdvancedIndex]?.weight || 1}
                  onChange={(e) => updateAdvancedSettings('weight', parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-1">
                  Popup Message
                </label>
                <Input
                  type="text"
                  placeholder="Message to show when selected"
                  value={choices[editingAdvancedIndex]?.popupMessage || ''}
                  onChange={(e) => updateAdvancedSettings('popupMessage', e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Result Dialog */}
      <Dialog open={showResultDialog} onOpenChange={setShowResultDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">🎉 Result!</DialogTitle>
          </DialogHeader>
          {selectedIndex !== null && (
            <div className="text-center space-y-4">
              <div
                className="w-20 h-20 rounded-full mx-auto shadow-lg"
                style={{ backgroundColor: choices[selectedIndex].color }}
              ></div>
              <div>
                <p className="text-slate-600 text-sm mb-1">You got:</p>
                <p className="text-3xl font-bold text-slate-900">
                  {choices[selectedIndex].name}
                </p>
              </div>
              {choices[selectedIndex].popupMessage && (
                <p className="text-slate-700 italic">
                  {choices[selectedIndex].popupMessage}
                </p>
              )}
            </div>
          )}
          <DialogFooter className="flex gap-2 justify-center">
            <Button
              onClick={handleKeepInWheel}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              Keep & Spin Again
            </Button>
            <Button
              onClick={handleRemoveFromResult}
              variant="destructive"
            >
              Remove from Wheel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
